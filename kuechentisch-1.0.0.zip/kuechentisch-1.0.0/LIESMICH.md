# Küchentisch

Der Familienplaner, der auf eurem eigenen Server läuft. Kalender, Einkaufslisten, Aufgaben,
Dienste, Essensplan, Fotoalben, Pinnwand, Taschengeld und ein Chat für die Familie — alle
Daten auf eurer Maschine, keine Cloud, keine Werbung, keine Auswertung.

**Fassung: 1.0.0**

## Was ihr braucht

* Einen Rechner, der durchläuft: eine NAS mit Docker (QNAP, Synology), einen kleinen Server
  oder einen Raspberry Pi 4/5 mit 64-Bit-System und einer SSD.
* **Docker** und **Docker Compose**. Auf einer QNAP heißt das „Container Station".
* Etwa 2 GB Platz für die Abbilder, dazu Platz für eure Fotos.
* 20 Minuten.

Nicht nötig: eine feste IP-Adresse, ein offener Port im Router, ein Konto bei irgendwem.

## Einrichten

```bash
bash scripts/erststart.sh
bash scripts/starten.sh
```

Das erste Skript stellt die Fragen, die vor dem Start beantwortet sein müssen — unter
welchem Namen Küchentisch erreichbar ist, welche Art Zertifikat, welche Ports — und
schreibt daraus die Datei `.env`. Das Datenbankkennwort erzeugt es selbst; niemand muss es
sich merken.

Das zweite lädt die Abbilder, startet alles und sagt danach, **unter welcher Adresse es
erreichbar ist**. Dort im Browser weiter: Küchentisch fragt nach dem Namen eurer Familie,
legt den ersten Zugang an und ist fertig.

## Aktualisieren

```bash
bash scripts/aktualisieren.sh
```

Holt die neueste Fassung und startet damit neu. Eure Daten bleiben unangetastet;
Anpassungen an der Datenbank erledigt die App beim Start selbst. Scheitert das Holen, wird
nichts verändert — die bisherige Fassung läuft weiter.

## Die drei Arten von HTTPS

**Ohne HTTPS fehlen zwei Dinge**, und das ist keine Meinung dieses Programms, sondern eine
Regel der Browser: Die Seiten gehen im Funkloch nicht auf (kein Offline-Betrieb), und
Erinnerungen kommen nicht an. Der Erststart fragt danach:

* **eigene-domain** — ein echtes Zertifikat von Let's Encrypt, geprüft über einen
  DNS-Eintrag. Kein offener Port, keine Erreichbarkeit von außen nötig; der Name darf auf
  eine Adresse im Heimnetz zeigen. Jedes Gerät vertraut ohne Zutun. **Der empfohlene Weg.**
  Voraussetzung ist eine Domain bei einem Anbieter mit Schnittstelle — deSEC, Cloudflare,
  Netcup, Hetzner, INWX und DuckDNS sind eingebaut.
* **intern** — der Server stellt das Zertifikat selbst aus. Nichts zu besorgen, aber sein
  Wurzelzertifikat muss auf **jedes** Gerät der Familie, sonst warnt der Browser und
  Offline-Betrieb und Erinnerungen bleiben dort tot. Zum Ausprobieren gut.
* **hinter-proxy** — die Verschlüsselung endet woanders (NAS-Oberfläche, vorhandener
  Proxy). Wer das wählt, sorgt selbst dafür, dass davor HTTPS steht.

## Sicherung

Jede Nacht schreibt Küchentisch eine Sicherung der Datenbank nach `data/backup` und hebt
sie so viele Tage auf, wie beim Erststart angegeben. **Die Fotos sind darin nicht
enthalten** — sie liegen in `data/media` und gehören in eure übliche Sicherung.

Eine Sicherung, die nie zurückgeholt wurde, ist eine Vermutung. Wie das Zurückholen geht,
steht in `ANLEITUNG.pdf`; einmal im Quartal ausprobieren.

## Wenn etwas klemmt

In dieser Reihenfolge: `docker compose ps` — läuft alles? `docker compose logs -f app` —
was sagt die App? Und in der App unter **Einstellungen → Systemcheck** steht in Worten,
was fehlt und was dagegen zu tun ist.

Alle Befehle mit Erklärung stehen in `ANLEITUNG.pdf`.

## Lizenz

Küchentisch ist keine freie Software. Was ihr damit dürft, steht in `LICENSE`. Die
mitgelieferten fremden Bibliotheken und ihre Lizenzen stehen in `LIZENZEN-DRITTER.txt`.

Fragen: Info@kuechentisch-familienplaner.de
