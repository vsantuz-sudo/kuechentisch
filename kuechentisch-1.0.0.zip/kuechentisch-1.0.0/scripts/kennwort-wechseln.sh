#!/usr/bin/env bash
#
# Das Kennwort der Datenbank wechseln — an beiden Stellen zugleich.
#
# Warum es dieses Skript gibt und nicht einen Knopf in der App:
#
# Das Kennwort steht an **zwei** Orten, die zusammenpassen müssen: in der
# Datenbank selbst und in der `.env`, aus der App, Datenbank und
# Sicherungsdienst es beim Start lesen. Wer nur eines von beiden ändert, merkt
# das nicht sofort — die laufende Verbindung bleibt bestehen —, sondern beim
# nächsten Neustart: Dann kommt die App nicht mehr an ihre eigenen Daten, und
# die ganze Familie steht vor einem Programm, das nicht mehr startet.
#
# Die App selbst kann das nicht leisten. Sie läuft in einem Container, sieht die
# `.env` des Wirtssystems nicht und darf die anderen Container nicht neu
# starten. Ihr das beizubringen hieße, ihr den Docker-Zugang zu geben — und wer
# den hat, ist auf der NAS faktisch root. Für einen Handgriff, den man einmal im
# Jahr macht, ist das der falsche Tausch.
#
# Also hier, auf dem Wirtssystem, wo die Zuständigkeit sitzt:
#
#   bash scripts/kennwort-wechseln.sh
#
# Nicht-interaktiv (für Prüfläufe):
#   KT_NICHT_FRAGEN=1 bash scripts/kennwort-wechseln.sh
#
set -euo pipefail

ROT=$'\033[0;31m'; GRUEN=$'\033[0;32m'; GELB=$'\033[0;33m'; FETT=$'\033[1m'; AUS=$'\033[0m'

sage()    { printf '%s\n' "$*"; }
gut()     { printf '%s✓%s %s\n' "$GRUEN" "$AUS" "$*"; }
warn()    { printf '%s!%s %s\n' "$GELB" "$AUS" "$*"; }
abbruch() { printf '%s✗%s %s\n' "$ROT" "$AUS" "$*" >&2; exit 1; }

WURZEL="$(cd "$(dirname "$0")/.." && pwd)"
ENV="${KT_ENV:-$WURZEL/.env}"
COMPOSE="${KT_COMPOSE:-docker compose}"

[ -f "$ENV" ] || abbruch "Keine .env gefunden: $ENV"

# Ein Kennwort, das niemand tippen muss. Ohne Sonderzeichen: Es landet in einer
# Verbindungsadresse (postgres://kt:…@db/…), und dort müssten `@`, `:` und `/`
# umständlich kodiert werden — ein Fehler, der erst beim nächsten Start auffällt.
neues() {
	if command -v openssl >/dev/null 2>&1; then
		openssl rand -base64 30 | tr -d '/+=\n' | cut -c1-32
	else
		LC_ALL=C tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 32
	fi
}

ALT="$(grep -E '^DB_PASSWORD=' "$ENV" | head -1 | cut -d= -f2- || true)"
[ -n "$ALT" ] || abbruch "In $ENV steht kein DB_PASSWORD."

NEU="${KT_NEUES_KENNWORT:-$(neues)}"

sage ""
sage "${FETT}Kennwort der Datenbank wechseln${AUS}"
sage ""
sage "  Was gleich passiert, in dieser Reihenfolge:"
sage "    1. Sicherungskopie der .env"
sage "    2. Neues Kennwort in der Datenbank setzen (ALTER ROLE)"
sage "    3. Neues Kennwort in die .env schreiben"
sage "    4. Container neu starten, damit beides zusammenpasst"
sage ""
sage "  Die Daten bleiben unberührt. Schlägt Schritt 2 fehl, wird nichts geändert."
sage ""

if [ "${KT_NICHT_FRAGEN:-}" != "1" ]; then
	read -r -p "  Weiter? [j/N]: " antwort || true
	case "${antwort:-n}" in
		j|J|y|Y) ;;
		*) sage "  Abgebrochen. Nichts geändert."; exit 0 ;;
	esac
fi

# 1. Sicherungskopie
KOPIE="$ENV.vor-kennwortwechsel-$(date +%Y%m%d-%H%M%S)"
cp "$ENV" "$KOPIE"
chmod 600 "$KOPIE"
gut "Sicherungskopie: $KOPIE"

# 2. In der Datenbank. Zuerst, weil ein Fehlschlag hier alles unberührt lässt —
#    andersherum stünde in der .env ein Kennwort, das die Datenbank nicht kennt.
if ! $COMPOSE exec -T db psql -U kt -d postgres -v ON_ERROR_STOP=1 \
	-c "alter role kt with password '$NEU'" >/dev/null 2>&1; then
	rm -f "$KOPIE"
	abbruch "Das Kennwort ließ sich in der Datenbank nicht setzen. Läuft der db-Container? ($COMPOSE ps)"
fi
gut "In der Datenbank gesetzt."

# 3. In der .env. Über eine Zwischendatei, damit ein Abbruch mitten im
#    Schreiben keine halbe .env hinterlässt.
TMP="$(mktemp)"
# Ersetzt wird nur DB_PASSWORD und das Kennwort in DATABASE_URL — awk statt sed,
# weil ein Kennwort Zeichen enthalten kann, die sed als Trennzeichen liest.
NEU="$NEU" awk '
	/^DB_PASSWORD=/ { print "DB_PASSWORD=" ENVIRON["NEU"]; next }
	/^DATABASE_URL=postgres:\/\/kt:/ {
		sub(/postgres:\/\/kt:[^@]*@/, "postgres://kt:" ENVIRON["NEU"] "@")
		print; next
	}
	{ print }
' "$ENV" > "$TMP"

if ! grep -q "^DB_PASSWORD=$NEU$" "$TMP"; then
	rm -f "$TMP"
	abbruch "Die .env ließ sich nicht schreiben. In der Datenbank gilt schon das neue Kennwort — es steht in $KOPIE NICHT drin. Jetzt von Hand eintragen: $NEU"
fi

cat "$TMP" > "$ENV"
rm -f "$TMP"
chmod 600 "$ENV"
gut "In die .env geschrieben."

# 4. Neu starten — `up -d`, nicht `restart`: Letzteres liest die .env nicht neu.
sage ""
sage "  Starte die Container neu …"
if $COMPOSE up -d >/dev/null 2>&1; then
	gut "Läuft."
else
	warn "Der Neustart hat gemeldet, dass etwas nicht stimmt."
	sage "  Nachsehen mit: $COMPOSE ps  und  $COMPOSE logs app"
fi

sage ""
sage "${FETT}Fertig.${AUS} Das alte Kennwort steht noch in der Sicherungskopie:"
sage "  $KOPIE"
sage ""
sage "  Sie enthält ein gültiges Kennwort von gestern — wenn alles läuft, gehört"
sage "  sie gelöscht:  rm $KOPIE"
sage ""
