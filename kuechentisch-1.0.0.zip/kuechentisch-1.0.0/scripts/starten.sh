#!/usr/bin/env bash
#
# Küchentisch starten — und danach sagen, wo es liegt.
#
#   bash scripts/starten.sh          # die Familieninstallation
#   bash scripts/starten.sh --demo   # zusätzlich den Dienst, der die Demo zurücksetzt
#
# Warum es dieses Skript gibt: `docker compose up -d` sagt, dass Container
# laufen, aber nicht, unter welcher Adresse man sie erreicht. Wer die Ports
# nicht auswendig weiß — und niemand weiß sie auswendig —, sucht danach in der
# .env, in der docker-compose.yml oder in `docker ps`. Das ist jedes Mal die
# gleiche Sucherei, und sie steht zwischen „gestartet" und „angesehen".
#
# Gefragt werden die **laufenden** Container, nicht die .env: Was dort steht,
# ist ein Wunsch; was `docker compose port` antwortet, ist die Wirklichkeit.
#
set -Eeuo pipefail

# Gemeldet wird der Befehl, nicht die Zeilennummer: LINENO zeigt in einem Trap
# auf älteren bash-Versionen irgendwohin, der Befehlstext stimmt immer.
trap 'printf "\033[0;31m✗\033[0m Fehlgeschlagen: %s\n" "${BASH_COMMAND:-unbekannt}" >&2' ERR

ROT=$'\033[0;31m'; GRUEN=$'\033[0;32m'; GELB=$'\033[0;33m'; FETT=$'\033[1m'; AUS=$'\033[0m'

sage()    { printf '%s\n' "$*"; }
gut()     { printf '%s✓%s %s\n' "$GRUEN" "$AUS" "$*"; }
warn()    { printf '%s!%s %s\n' "$GELB" "$AUS" "$*"; }
abbruch() { printf '%s✗%s %s\n' "$ROT" "$AUS" "$*" >&2; exit 1; }

WURZEL="$(cd "$(dirname "$0")/.." && pwd)"
cd "$WURZEL"

COMPOSE="${KT_COMPOSE:-docker compose}"
PROFIL=''
BAUEN='--build'

while [ $# -gt 0 ]; do
	case "$1" in
		--demo) PROFIL='--profile demo'; shift ;;
		--ohne-bauen) BAUEN=''; shift ;;
		-h|--hilfe|--help) sed -n '2,16p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
		*) abbruch "Unbekannte Angabe: $1" ;;
	esac
done

[ -f .env ] || abbruch "Keine .env gefunden. Erst 'bash scripts/erststart.sh' ausführen."

# Ohne docker-compose.override.yml gibt es keine Bauanleitung — dann ist das
# hier eine Installation, die fertige Abbilder aus der Registry lädt, und
# `--build` wäre bestenfalls wirkungslos.
if [ ! -f docker-compose.override.yml ]; then
	BAUEN=''
	AUS_REGISTRY=1
else
	AUS_REGISTRY=0
fi

# Werte aus der .env lesen, ohne sie auszuführen: Eine .env ist eine Textdatei
# und kein Shell-Skript, und `source` auf fremde Dateien ist eine schlechte
# Gewohnheit.
#
# Das `|| true` ist nicht Zierde: `grep` liefert 1, wenn es nichts findet, und
# mit `pipefail` schlägt dann die ganze Zuweisung fehl — `set -e` beendete das
# Skript stumm, sobald eine Zeile in der .env fehlte. Ausgerechnet KT_DEMO
# fehlt in jeder gewöhnlichen Familieninstallation.
aus_env() { grep -E "^$1=" .env 2>/dev/null | head -1 | cut -d= -f2- | tr -d '"'"'"'' || true ; }

KT_HOST="$(aus_env KT_HOST)"
KT_TLS="$(aus_env KT_TLS)"
KT_DEMO="$(aus_env KT_DEMO)"
KT_HTTPS_PORT="$(aus_env KT_HTTPS_PORT)"; KT_HTTPS_PORT="${KT_HTTPS_PORT:-8443}"

sage ""
sage "${FETT}Küchentisch starten${AUS}"
sage ""

# shellcheck disable=SC2086
$COMPOSE $PROFIL up -d $BAUEN || abbruch "Der Start ist fehlgeschlagen. Mehr sagt: $COMPOSE logs"

gut "Container laufen."
sage ""

# ── Wo es jetzt liegt ───────────────────────────────────────────────────────
#
# `docker compose port <dienst> <port im container>` antwortet mit dem, was
# tatsächlich veröffentlicht ist — etwa „0.0.0.0:8477". Antwortet es gar nicht,
# ist nichts veröffentlicht, und genau das gehört gesagt statt verschwiegen.

hafen() { # hafen <dienst> <port im container>
	$COMPOSE port "$1" "$2" 2>/dev/null | tail -1 | sed 's/.*://' || true
}

# Die Adresse dieses Rechners im Heimnetz — damit man von einem anderen Gerät
# aus etwas zum Eintippen hat.
adresse() {
	if command -v hostname >/dev/null 2>&1; then
		hostname -I 2>/dev/null | awk '{print $1}' && return
	fi
	ip -o -4 addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -1
}

IP="$(adresse 2>/dev/null || true)"
IP="${IP:-<Adresse dieser NAS>}"

APP_HAFEN="$(hafen app 3000)"
TLS_HAFEN="$(hafen caddy "$KT_HTTPS_PORT")"

sage "${FETT}Erreichbar unter:${AUS}"
sage ""

# Löst der Name überhaupt auf? Ein Name, den kein Router kennt, ergibt im
# Browser „Die Website ist nicht erreichbar" — und das sieht aus, als wäre
# nichts gestartet, obwohl alles läuft. Geprüft wird von hier aus; der Browser
# sitzt woanders, fragt aber in aller Regel denselben Router.
loest_auf() { # loest_auf <Name>
	[ -n "$1" ] || return 1
	if command -v getent >/dev/null 2>&1; then getent hosts "$1" >/dev/null 2>&1 && return 0; fi
	if command -v nslookup >/dev/null 2>&1; then nslookup "$1" >/dev/null 2>&1 && return 0; fi
	if command -v ping >/dev/null 2>&1; then ping -c 1 -w 2 "$1" >/dev/null 2>&1 && return 0; fi
	return 1
}

NAME_OK=1
loest_auf "$KT_HOST" || NAME_OK=0

if [ -n "$TLS_HAFEN" ] && [ -z "$KT_HOST" ]; then
	warn "KT_HOST ist leer — HTTPS hat damit keine Adresse."
	sage "      Caddy antwortet **nur auf einen Namen**, nicht auf eine IP;"
	sage "      https://$IP:$TLS_HAFEN kann deshalb nicht funktionieren."
	sage "      KT_HOST in der .env setzen und neu starten."
	sage ""
elif [ -n "$TLS_HAFEN" ]; then
	sage "  ${FETT}https://${KT_HOST}:${TLS_HAFEN}${AUS}"
	sage "      Der richtige Weg — verschlüsselt. Nur darüber funktionieren"
	sage "      Benachrichtigungen und der Offline-Betrieb."
	sage ""
	sage "      ${FETT}Nur über diesen Namen.${AUS} https://$IP:$TLS_HAFEN geht nicht,"
	sage "      und zwar aus zwei Gründen, die sich beide nicht einstellen lassen:"
	sage "      Caddy entscheidet am Namen der Anfrage, welche Seite es ausliefert"
	sage "      — eine Anfrage mit einer IP passt auf keine. Und für eine private"
	sage "      Adresse stellt keine Zertifizierungsstelle ein Zertifikat aus."
	sage "      Über die IP gibt es nur http, und das als Notweg."
	if [ "$NAME_OK" = "0" ]; then
		sage ""
		warn "Der Name $KT_HOST ist hier nicht auflösbar."
		sage "      Im Browser kommt dann „Die Website ist nicht erreichbar\" —"
		sage "      obwohl alles läuft. Entweder im Router einen Namenseintrag"
		sage "      anlegen, oder KT_HOST in der .env auf den Namen ändern, unter"
		sage "      dem diese NAS schon erreichbar ist. Bis dahin tut es die"
		sage "      Adresse darunter."
	fi
	sage ""
else
	warn "Für HTTPS ist kein Port veröffentlicht."
	sage "      Läuft der caddy-Dienst? $COMPOSE ps"
	sage ""
fi

if [ -n "$APP_HAFEN" ]; then
	sage "  http://${IP}:${APP_HAFEN}"
	sage "      Unverschlüsselt, nur im Heimnetz. Zum Ausprobieren gut,"
	sage "      für den Alltag nicht: ohne https bleiben Erinnerungen und"
	sage "      der Offline-Betrieb tot."
	sage ""
fi

if [ "$KT_DEMO" = "1" ]; then
	ZIEL="${TLS_HAFEN:+https://${KT_HOST:-$IP}:${TLS_HAFEN}}"
	ZIEL="${ZIEL:-http://${IP}:${APP_HAFEN}}"

	sage "  ${FETT}${ZIEL}/demo${AUS}"
	sage "      Der Eingang zur Demo: ohne Anmeldung, als Anna."
	sage ""

	if [ -n "$PROFIL" ]; then
		gut "Der Dienst demo-reset läuft und füllt stündlich neu."
	else
		warn "Der Dienst demo-reset läuft NICHT — ohne ihn wird nichts zurückgesetzt."
		sage "      Starten mit: bash scripts/starten.sh --demo"
	fi
	sage ""
	sage "      Einmal von Hand füllen (beim ersten Mal nötig):"
	sage "          $COMPOSE exec app node scripts/demo-daten.mjs"
	sage ""
elif [ -n "$PROFIL" ]; then
	warn "Das Demo-Profil ist gestartet, aber KT_DEMO=1 fehlt in der .env."
	sage "      Ohne die Zeile bleibt die App eine gewöhnliche Installation:"
	sage "      kein Banner, kein /demo, und der Reset räumt einen Haushalt weg,"
	sage "      den niemand sieht."
	sage ""
fi

if [ "$KT_TLS" = "intern" ]; then
	sage "  ${FETT}KT_TLS=intern — das Zertifikat ist selbst ausgestellt.${AUS}"
	sage "  Der Browser warnt beim ersten Aufruf, und auf jedem Gerät muss Caddys"
	sage "  Wurzelzertifikat installiert werden. Eine weggeklickte Warnung genügt"
	sage "  dem Browser **nicht**: Ohne das Wurzelzertifikat meldet er den Service"
	sage "  Worker nicht an, und damit bleiben Offline-Betrieb und Erinnerungen"
	sage "  tot — ohne dass irgendwo ein Fehler stünde."
	sage ""
	sage "  Wer das Wurzelzertifikat schon einmal entfernt hat, sieht genau das:"
	sage "  https mit dem Namen warnt, https mit der IP geht gar nicht. Beides ist"
	sage "  kein Fehler, sondern diese Betriebsart."
	sage ""
	sage "  Der Ausweg ist KT_TLS=eigene-domain: ein echtes Zertifikat über die"
	sage "  DNS-Prüfung, ohne offenen Port, mit einem Namen, der auf die Adresse"
	sage "  im Heimnetz zeigt. Dann vertraut jedes Gerät von sich aus. Siehe"
	sage "  README, Abschnitt „HTTPS\"."
	sage ""
fi

if [ "$AUS_REGISTRY" = "1" ]; then
	sage "  Neue Fassung holen:  bash scripts/aktualisieren.sh"
fi
sage "  Was gerade läuft:  $COMPOSE ps"
sage "  Was es sagt:       $COMPOSE logs -f app"
sage ""
