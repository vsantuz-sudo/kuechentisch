/**
 * Migrationen einspielen. Läuft beim Containerstart vor der App.
 * Wartet auf die Datenbank, damit die Reihenfolge beim Hochfahren egal ist.
 */
import postgres from 'postgres';
import { drizzle } from 'drizzle-orm/postgres-js';
import { migrate } from 'drizzle-orm/postgres-js/migrator';

const url = process.env.DATABASE_URL;

if (!url) {
	console.error('DATABASE_URL fehlt.');
	process.exit(1);
}

const VERSUCHE = 30;

for (let versuch = 1; versuch <= VERSUCHE; versuch++) {
	const client = postgres(url, { max: 1, onnotice: () => {} });
	try {
		await migrate(drizzle(client), { migrationsFolder: './drizzle' });
		await client.end();
		console.log('Migrationen eingespielt.');
		process.exit(0);
	} catch (err) {
		await client.end().catch(() => {});
		if (versuch === VERSUCHE) {
			console.error('Migration fehlgeschlagen:', err instanceof Error ? err.message : err);
			process.exit(1);
		}
		console.log(`Datenbank noch nicht bereit (Versuch ${versuch}/${VERSUCHE}) …`);
		await new Promise((r) => setTimeout(r, 2000));
	}
}
