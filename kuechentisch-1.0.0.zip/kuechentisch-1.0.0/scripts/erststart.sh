#!/usr/bin/env bash
#
# Küchentisch zum ersten Mal einrichten — die Fragen vor dem ersten Start.
#
# Es gibt zwei Sorten Einstellungen, und sie lassen sich nicht am selben Ort
# beantworten:
#
#   1. Was die **App** wissen muss: wie die Familie heißt, wer dazugehört,
#      welches Bundesland für die Schulferien. Das fragt die App selbst, beim
#      ersten Öffnen im Browser. Dafür ist dieses Skript nicht zuständig.
#
#   2. Was der **Container** wissen muss, bevor er überhaupt startet: unter
#      welchem Namen er erreichbar ist, welche Art Zertifikat, welcher
#      Zugangsschlüssel beim DNS-Anbieter, welche Ports, welches
#      Datenbankkennwort. Das steht in `.env`, und `.env` muss existieren,
#      bevor `docker compose` das erste Mal läuft.
#
# Genau diese zweite Sorte fragt dieses Skript ab und schreibt sie in `.env`.
# Vorher war das „kopiere .env.example nach .env und lies neunzig Zeilen
# Kommentar" — machbar für den, der das Ding geschrieben hat, und eine Hürde
# für jeden anderen.
#
# Es überschreibt niemals eine vorhandene `.env`. Eine falsch beantwortete
# Frage kostet einen neuen Durchlauf, ein überschriebenes Kennwort kostet die
# Datenbank.
#
# Nicht-interaktiv (für Prüfläufe):
#   KT_NICHT_FRAGEN=1 KT_HOST=… KT_TLS=… KT_DNS_TOKEN=… ./scripts/erststart.sh
#
set -Eeuo pipefail

# Ohne diese Zeile endet jeder Fehler, der keine eigene Meldung schreibt, in
# einem Skript, das einfach aufhört — und der Benutzer sieht eine leere Zeile
# und eine nicht geschriebene Datei. Mit ihr steht wenigstens die Zeilennummer da.
# Gemeldet wird der **Befehl**, nicht die Zeilennummer: In einem Trap zeigt
# LINENO auf älteren bash-Versionen irgendwohin — auf der QNAP mitten in einen
# Kommentar. Der Befehlstext stimmt immer.
trap 'printf "\033[0;31m✗\033[0m Fehlgeschlagen: %s\n" "${BASH_COMMAND:-unbekannt}" >&2' ERR

ROT=$'\033[0;31m'; GRUEN=$'\033[0;32m'; GELB=$'\033[0;33m'; FETT=$'\033[1m'; AUS=$'\033[0m'

sage()    { printf '%s\n' "$*"; }
gut()     { printf '%s✓%s %s\n' "$GRUEN" "$AUS" "$*"; }
warn()    { printf '%s!%s %s\n' "$GELB" "$AUS" "$*"; }
abbruch() { printf '%s✗%s %s\n' "$ROT" "$AUS" "$*" >&2; exit 1; }

ZIEL=''
while [ $# -gt 0 ]; do
	case "$1" in
		--ziel) ZIEL="${2:-}"; shift 2 ;;
		-h|--hilfe|--help)
			sed -n '2,28p' "$0" | sed 's/^# \{0,1\}//'
			exit 0 ;;
		*) abbruch "Unbekannte Angabe: $1" ;;
	esac
done

if [ -z "$ZIEL" ]; then
	WURZEL="$(cd "$(dirname "$0")/.." && pwd)"
	ZIEL="$WURZEL/.env"
fi

FRAGEN=1
[ "${KT_NICHT_FRAGEN:-}" = "1" ] && FRAGEN=0

# Den schon gesetzten Wert holen — `${VAR-}` statt `${!name:-…}`: Die
# indirekte Form ist mit `set -u` auf älteren bash-Versionen eine Falle.
schonDa() { # schonDa <Variablenname>
	eval "printf '%s' \"\${$1-}\""
}

frage() { # frage <Text> <Vorgabe> <Variable>
	local text="$1" vorgabe="$2" __ziel="$3" antwort='' jetzt=''
	jetzt="$(schonDa "$__ziel")"
	if [ "$FRAGEN" = "0" ]; then
		printf -v "$__ziel" '%s' "${jetzt:-$vorgabe}"
		return 0
	fi
	read -r -p "$text [$vorgabe]: " antwort || true
	printf -v "$__ziel" '%s' "${antwort:-$vorgabe}"
	return 0
}

geheim() { # geheim <Text> <Variable> — die Eingabe bleibt unsichtbar
	local text="$1" __ziel="$2" antwort=''
	if [ "$FRAGEN" = "0" ]; then
		printf -v "$__ziel" '%s' "$(schonDa "$__ziel")"
		return 0
	fi
	read -r -s -p "$text: " antwort || true
	printf '\n'
	printf -v "$__ziel" '%s' "$antwort"
}

# Ein Kennwort, das niemand tippen muss und deshalb auch niemand errät.
kennwort() {
	local roh=''

	# Kein `tr < /dev/urandom | head -c 32`: `head` hört nach 32 Zeichen auf,
	# `tr` bekommt daraufhin SIGPIPE — und mit `pipefail` stirbt davon das
	# ganze Skript, ohne ein Wort zu sagen. Deshalb liest `dd` eine endliche
	# Menge, und niemand muss eine Pipe vorzeitig schließen.
	if command -v openssl >/dev/null 2>&1; then
		roh="$(openssl rand -base64 48 2>/dev/null | LC_ALL=C tr -dc 'A-Za-z0-9' | cut -c1-32 || true)"
	fi

	if [ "${#roh}" -lt 24 ]; then
		roh="$(dd if=/dev/urandom bs=512 count=1 2>/dev/null | LC_ALL=C tr -dc 'A-Za-z0-9' | cut -c1-32 || true)"
	fi

	[ "${#roh}" -ge 24 ] || abbruch "Konnte kein Kennwort erzeugen — weder mit openssl noch aus /dev/urandom."
	printf '%s' "$roh"
}

istPort() { case "$1" in ''|*[!0-9]*) return 1 ;; esac; [ "$1" -ge 1 ] && [ "$1" -le 65535 ]; }

# ── Was für ein Rechner ist das hier? ───────────────────────────────────────
#
# Geprüft wird VOR den Fragen, nicht hinterher: Wer zwanzig Minuten auf einen
# Build wartet, der am Arbeitsspeicher scheitert, hat den Abend verloren — und
# die Meldung von Docker sagt dann „killed", nicht „zu wenig Speicher".
#
# Alles hier warnt nur. Es ist der Rechner des Benutzers; er darf es besser
# wissen. Für Prüfläufe lassen sich die Tatsachen über KT_PROBE_* setzen.

zahlAus() { # zahlAus <Datei> <Feld> — Megabyte aus /proc/meminfo
	awk -v f="$2" '$1 == f":" { print int($2 / 1024) }' "$1" 2>/dev/null || true
}

# Wieviel Platz, welches Gerät.
#
# Hier steckte ein Fehler, der einen Abend gekostet hat: `df --output=` gibt es
# nur im GNU-df. Auf einer QNAP (BusyBox) scheitert der Aufruf — und weil die
# Zeile eine Pipe war, machte `pipefail` daraus einen Fehlschlag der ganzen
# Zuweisung, `set -e` beendete das Skript, und weil der Fehlertext von df
# unterdrückt war, stand am Ende gar nichts da. Das Skript hörte nach der
# Überschrift einfach auf.
#
# Deshalb: erst GNU, dann der Weg, den jedes df kennt, und am Ende jeder
# Kette ein `|| true`. Diese Angaben sind ein Hinweis wert, aber keinen
# Abbruch.

platzGB() { # platzGB <Ordner> — freie Gigabyte, oder nichts
	local aus
	aus="$(df -BG --output=avail "$1" 2>/dev/null | tail -1 | tr -dc '0-9' || true)"
	[ -n "$aus" ] || aus="$(df -k "$1" 2>/dev/null | awk 'NR > 1 { print int($4 / 1048576); exit }' || true)"
	printf '%s' "$aus"
}

geraetVon() { # geraetVon <Ordner> — auf welchem Gerät er liegt, oder nichts
	local aus
	aus="$(df --output=source "$1" 2>/dev/null | tail -1 || true)"
	[ -n "$aus" ] || aus="$(df -k "$1" 2>/dev/null | awk 'NR > 1 { print $1; exit }' || true)"
	printf '%s' "$aus"
}

pruefeMaschine() {
	local arch ram swap frei geraet hinweise=0

	arch="${KT_PROBE_ARCH:-$(uname -m 2>/dev/null || echo unbekannt)}"
	ram="${KT_PROBE_RAM_MB:-$(zahlAus /proc/meminfo MemTotal)}"
	swap="${KT_PROBE_SWAP_MB:-$(zahlAus /proc/meminfo SwapTotal)}"
	frei="${KT_PROBE_FREI_GB:-$(platzGB "$(dirname "$ZIEL")")}"
	geraet="${KT_PROBE_GERAET:-$(geraetVon "$(dirname "$ZIEL")")}"

	case "$arch" in
		armv6l|armv7l|armhf)
			warn "Dieser Rechner läuft mit einem 32-Bit-System ($arch)."
			sage "  Küchentisch braucht ein 64-Bit-System. Auf einem Raspberry Pi 4"
			sage "  oder 5 heißt das: Raspberry Pi OS (64 bit) neu aufsetzen. Mit dem"
			sage "  32-Bit-System scheitert entweder der Build — oder später die"
			sage "  Bildverarbeitung, sichtbar erst beim ersten Foto."
			hinweise=1 ;;
		aarch64|arm64)
			gut "64-Bit-ARM erkannt ($arch) — Raspberry Pi 4/5 und ähnliche laufen."
			;;
	esac

	if [ -n "$ram" ] && [ "$ram" -gt 0 ] 2>/dev/null; then
		local gesamt=$(( ram + ${swap:-0} ))
		if [ "$gesamt" -lt 2600 ]; then
			warn "Nur ${ram} MB Arbeitsspeicher (mit Auslagerung ${gesamt} MB)."
			sage "  Nicht der Betrieb ist das Problem, sondern das ${FETT}Bauen${AUS}: Das"
			sage "  Übersetzen des Frontends und von Caddy braucht kurzzeitig gut"
			sage "  1,5 GB. Läuft es aus dem Speicher, bricht Docker mit \"killed\" ab."
			sage "  Zwei Auswege: Auslagerungsdatei vergrößern — auf einem Pi in"
			sage "  /etc/dphys-swapfile CONF_SWAPSIZE=2048 setzen und den Dienst"
			sage "  dphys-swapfile neu starten — oder das Abbild auf einem größeren"
			sage "  Rechner bauen und herüberkopieren."
			hinweise=1
		fi
	fi

	case "$geraet" in
		*mmcblk*)
			warn "Das Projekt liegt auf einer SD-Karte ($geraet)."
			sage "  Die Datenbank schreibt ununterbrochen, dazu kommen die Fotos. Eine"
			sage "  SD-Karte ist dafür langsam und geht irgendwann kaputt — ohne"
			sage "  Vorwarnung und mitsamt allem, was die Familie eingetragen hat."
			sage "  Eine USB-SSD ist hier keine Feinheit, sondern die Bedingung dafür,"
			sage "  dass die Daten in zwei Jahren noch da sind."
			hinweise=1 ;;
	esac

	if [ -n "$frei" ] && [ "$frei" -lt 5 ] 2>/dev/null; then
		warn "Nur noch ${frei} GB frei. Die Abbilder brauchen etwa 3 GB, dazu"
		sage "  kommen Datenbank, Fotos und die nächtlichen Sicherungen."
		hinweise=1
	fi

	[ "$hinweise" = "1" ] && sage ""
	return 0
}


# ── Los ─────────────────────────────────────────────────────────────────────

sage ""
sage "${FETT}Küchentisch einrichten${AUS}"
sage ""

if [ -e "$ZIEL" ]; then
	warn "Es gibt schon eine Konfiguration: $ZIEL"
	sage "  Dieses Skript überschreibt sie nicht. Wer neu anfangen will,"
	sage "  benennt die Datei um und ruft das Skript noch einmal auf."
	exit 0
fi

# `|| true` ist hier nicht Schlamperei, sondern die Regel dieser Funktion: Sie
# **warnt** über Arbeitsspeicher, Platz und Datenträger. Ein Befehl darin, den
# es auf einem fremden System nicht gibt, darf die Einrichtung nicht abbrechen
# — und weil ein Funktionsaufruf in einer Bedingung `set -e` für den ganzen
# Rumpf abschaltet, kann ab hier nichts darin mehr das Skript beenden.
pruefeMaschine || true

sage "Ein paar Fragen, dann steht die Konfiguration. Was in eckigen Klammern"
sage "steht, gilt, wenn du einfach die Eingabetaste drückst."
sage ""

# 1. Erreichbarkeit
sage "${FETT}1. Unter welchem Namen ist Küchentisch erreichbar?${AUS}"
sage "   Ein Name, den die Geräte zu Hause auflösen können — bei einer Fritzbox"
sage "   zum Beispiel nas.fritz.box. Wenn du eine eigene Domain benutzen willst,"
sage "   trag sie hier ein (kuechentisch.deine-domain.de)."
sage "   Dieser Name steht außerdem als Absender in jeder Benachrichtigung."
frage "   Name" "kuechentisch.fritz.box" KT_HOST
[ -n "$KT_HOST" ] || abbruch "Ohne Namen geht es nicht."
sage ""

# 2. Zertifikat
sage "${FETT}2. Welche Art Zertifikat?${AUS}"
sage "   Ohne HTTPS bleiben Offline-Betrieb und Benachrichtigungen tot — das ist"
sage "   keine Meinung des Programms, sondern eine Regel der Browser."
sage ""
sage "   1) eigene-domain  Echtes Zertifikat von Let's Encrypt über die DNS-Prüfung."
sage "                     Kein Gerät muss etwas installieren. Der empfohlene Weg."
sage "                     Voraussetzung: eine Domain bei einem Anbieter mit"
sage "                     Schnittstelle (deSEC, Cloudflare, Netcup, Hetzner, …)."
sage "   2) intern         Caddy stellt es selbst aus. Nichts zu besorgen, aber das"
sage "                     Wurzelzertifikat muss auf JEDES Gerät der Familie."
sage "                     Zum Ausprobieren gut, auf Dauer eine Zumutung."
sage "   3) hinter-proxy   TLS endet woanders (NAS-Oberfläche, vorhandener Proxy)."
frage "   Auswahl (1/2/3)" "1" KT_WAHL

case "${KT_TLS:-}" in
	eigene-domain|intern|hinter-proxy) ;;   # schon gesetzt (nicht-interaktiv)
	*)
		case "$KT_WAHL" in
			1|eigene-domain) KT_TLS=eigene-domain ;;
			2|intern)        KT_TLS=intern ;;
			3|hinter-proxy)  KT_TLS=hinter-proxy ;;
			*) abbruch "Bitte 1, 2 oder 3." ;;
		esac ;;
esac
sage ""

KT_DNS_ANBIETER="${KT_DNS_ANBIETER:-desec}"
KT_DNS_SCHLUESSEL="${KT_DNS_SCHLUESSEL:-token}"
KT_DNS_TOKEN="${KT_DNS_TOKEN:-}"

if [ "$KT_TLS" = "eigene-domain" ]; then
	sage "${FETT}3. Wer verwaltet die Namensauflösung dieser Domain?${AUS}"
	sage "   Let's Encrypt prüft über einen DNS-Eintrag, dass die Domain dir"
	sage "   gehört. Dafür setzt Caddy den Eintrag selbst — und braucht einen"
	sage "   Zugangsschlüssel des Anbieters."
	frage "   Anbieter (desec, cloudflare, netcup, hetzner, inwx, duckdns)" "desec" KT_DNS_ANBIETER

	case "$KT_DNS_ANBIETER" in
		desec|duckdns|netcup|hetzner|inwx) KT_DNS_SCHLUESSEL="token" ;;
		cloudflare) KT_DNS_SCHLUESSEL="api_token" ;;
		*) frage "   Wie nennt das Modul den Schlüssel?" "token" KT_DNS_SCHLUESSEL ;;
	esac

	sage ""
	sage "   Der Schlüssel wird beim Tippen nicht angezeigt und landet nur in"
	sage "   der .env auf diesem Rechner."
	geheim "   Zugangsschlüssel" KT_DNS_TOKEN
	[ -n "$KT_DNS_TOKEN" ] || abbruch "Ohne Schlüssel kann Caddy kein Zertifikat holen."
	sage ""

	sage "   Zwei Dinge, die außerhalb dieser Datei stimmen müssen:"
	sage "     • Ein A-Eintrag für $KT_HOST, der auf die Adresse der NAS im"
	sage "       Heimnetz zeigt (192.168.x.y). Das ist erlaubt."
	sage "     • Eine Ausnahme im DNS-Rebind-Schutz des Routers — sonst gibt eine"
	sage "       Fritzbox für einen öffentlichen Namen keine private Adresse"
	sage "       heraus, und im ganzen Haus kommt niemand an."
	sage ""
fi

# 4. Ports
sage "${FETT}4. Ports${AUS}"
sage "   Auf einer QNAP sind 80, 443 und 8080 meist schon belegt."
frage "   HTTPS-Port" "8443" KT_HTTPS_PORT
istPort "$KT_HTTPS_PORT" || abbruch "„$KT_HTTPS_PORT\" ist kein Port."
frage "   Port der App (nur im Heimnetz, ohne Verschlüsselung)" "8477" APP_PORT
istPort "$APP_PORT" || abbruch "„$APP_PORT\" ist kein Port."
KT_HTTP_PORT="${KT_HTTP_PORT:-8480}"
sage ""

# 5. Sicherung
frage "${FETT}5. Wie viele Tage sollen Sicherungen aufgehoben werden?${AUS}" "14" BACKUP_TAGE
sage ""

DB_PASSWORD="${DB_PASSWORD:-$(kennwort)}"

umask 177
cat > "$ZIEL" <<ENDE
# Von scripts/erststart.sh geschrieben am $(date '+%d.%m.%Y %H:%M').
#
# Diese Datei enthält Kennwörter. Sie gehört nicht ins Repository und nicht in
# eine Sicherung, die jemand anders lesen kann.
#
# Was die App selbst betrifft — Name der Familie, Mitglieder, Bundesland —
# wird beim ersten Öffnen im Browser gefragt, nicht hier.

# Selbst erzeugt, muss sich niemand merken. Ändern heißt: die Datenbank
# kennt das neue Kennwort nicht und lässt niemanden mehr herein.
DB_PASSWORD=$DB_PASSWORD

APP_PORT=$APP_PORT
MEDIA_DIR=./data/media

# Nur für die Entwicklung außerhalb von Docker:
DATABASE_URL=postgres://kt:$DB_PASSWORD@localhost:5432/kuechentisch

# ── HTTPS ───────────────────────────────────────────────────────────────────
KT_TLS=$KT_TLS
KT_HOST=$KT_HOST
KT_HTTPS_PORT=$KT_HTTPS_PORT
KT_HTTP_PORT=$KT_HTTP_PORT

# ── Nur für KT_TLS=eigene-domain ────────────────────────────────────────────
KT_DNS_ANBIETER=$KT_DNS_ANBIETER
KT_DNS_TOKEN=$KT_DNS_TOKEN
KT_DNS_SCHLUESSEL=$KT_DNS_SCHLUESSEL
KT_DNS_WARTEZEIT=${KT_DNS_WARTEZEIT:-5m}

# ── Sicherung ───────────────────────────────────────────────────────────────
BACKUP_TAGE=$BACKUP_TAGE
ENDE
umask 022

# Registry und Fassung aus der Vorlage übernehmen.
#
# Im Kundenpaket stehen in der .env.example zwei Zeilen, die sagen, woher die
# fertigen Abbilder kommen. Ohne sie fiele die frische .env auf
# `kuechentisch:local` zurück — ein Abbild, das es auf einer Kundenmaschine
# nirgends gibt, und der erste Start endete mit „image not found". Wer selbst
# baut, hat diese Zeilen nicht in der Vorlage; dann wird auch nichts übernommen.
VORLAGE="$(dirname "$0")/../.env.example"
if [ -f "$VORLAGE" ]; then
	uebernommen=0
	for schluessel in KT_MARKE KT_FASSUNG; do
		zeile="$(grep -E "^$schluessel=" "$VORLAGE" 2>/dev/null | head -1 || true)"
		[ -n "$zeile" ] || continue
		if [ "$uebernommen" = "0" ]; then
			printf '\n# ── Woher die Abbilder kommen (aus .env.example übernommen) ────────────────\n' >> "$ZIEL"
			uebernommen=1
		fi
		printf '%s\n' "$zeile" >> "$ZIEL"
	done
fi

[ -s "$ZIEL" ] || abbruch "Die Datei $ZIEL ist leer geblieben."
gut "Geschrieben: $ZIEL"
sage ""
sage "${FETT}Weiter geht es so:${AUS}"
sage ""
sage "  bash scripts/starten.sh"
sage ""
sage "  Das startet und sagt danach, unter welcher Adresse es wirklich liegt."
sage ""
sage "  Danach im Browser:  https://$KT_HOST:$KT_HTTPS_PORT"
sage ""
sage "  Dort fragt Küchentisch nach dem Namen eurer Familie und legt den"
sage "  ersten Zugang an. Wer den Haushalt anlegt, verwaltet ihn."
sage ""
if [ "$KT_TLS" = "intern" ]; then
	warn "Beim ersten Aufruf warnt der Browser — das Zertifikat stammt von"
	sage "  eurem eigenen Server. Wie das Wurzelzertifikat auf die Geräte kommt,"
	sage "  steht in der README unter „intern“."
	sage ""
fi
if [ "$KT_TLS" = "eigene-domain" ]; then
	sage "  Das erste Zertifikat kann ein paar Minuten dauern — Caddy setzt einen"
	sage "  DNS-Eintrag und wartet, bis er verbreitet ist. Mitlesen mit:"
	sage "      docker compose logs -f caddy"
	sage ""
fi
