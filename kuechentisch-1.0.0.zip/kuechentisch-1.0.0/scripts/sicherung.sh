#!/bin/sh
# Die nächtliche Sicherung der Datenbank.
#
# Stand vorher in der `docker-compose.yml` als eingebettete Shell-Zeile. Dort
# ist ein Fehler zwei Wochen lang unbemerkt geblieben: Der Dateiname enthielt
# `date +%%Y%%m%%d`, und `%%` ergibt in der Shell ein wörtliches Prozentzeichen.
# `date` bekam also nie ein Format zu sehen, und jede Sicherung hieß
# `kuechentisch-%Y%m%d.dump` — **jede Nacht dieselbe Datei.**
#
# Der Schaden daran ist größer als der Tippfehler: Wer einen Datenverlust erst
# am nächsten Tag bemerkt, dessen letzte heile Sicherung ist dann schon von
# einer Sicherung des Schadens überschrieben. Aus vierzehn Tagen Schutz werden
# vierundzwanzig Stunden.
#
# Deshalb steht das jetzt hier: als Datei, die man lesen, prüfen und von einem
# Werkzeug wie ShellCheck durchleuchten lassen kann.

set -eu

ZIEL=${BACKUP_DIR:-/backup}
TAGE=${BACKUP_TAGE:-14}
ABSTAND=${BACKUP_ABSTAND:-86400}
DB=${PGDATABASE:-kuechentisch}
WIRT=${PGHOST:-db}
NUTZER=${PGUSER:-kt}

sicherung() {
	datum=$(date +%Y%m%d)
	ziel="$ZIEL/kuechentisch-$datum.dump"
	# Erst unter anderem Namen schreiben. Wird der Vorgang unterbrochen — die
	# NAS startet neu, die Platte ist voll —, bliebe sonst eine abgeschnittene
	# Datei liegen, die wie eine gültige Sicherung aussieht. Das ist schlimmer
	# als gar keine, weil man sich darauf verlässt.
	vorlaeufig="$ziel.teil"

	if ! pg_dump -h "$WIRT" -U "$NUTZER" -d "$DB" -Fc -f "$vorlaeufig"; then
		echo "FEHLER: pg_dump ist gescheitert, es wurde nichts geschrieben." >&2
		rm -f "$vorlaeufig"
		return 1
	fi

	# Nachsehen, ob sich die Datei überhaupt lesen lässt. `pg_restore -l`
	# liest nur das Inhaltsverzeichnis, ändert nichts und kostet nichts —
	# unterscheidet aber eine Sicherung von einer Datei, die so heißt.
	if ! pg_restore -l "$vorlaeufig" >/dev/null 2>&1; then
		echo "FEHLER: Die geschriebene Sicherung ist unlesbar und wird verworfen." >&2
		rm -f "$vorlaeufig"
		return 1
	fi

	mv "$vorlaeufig" "$ziel"
	echo "Sicherung geschrieben: $ziel ($(wc -c <"$ziel") Bytes)"

	# Reste früherer Abbrüche wegräumen.
	find "$ZIEL" -name 'kuechentisch-*.dump.teil' -mmin +60 -delete 2>/dev/null || true

	# Alte Sicherungen entfernen. Greift erst jetzt wirklich — vorher trugen
	# alle denselben Namen, und es gab nie etwas zu löschen.
	find "$ZIEL" -name 'kuechentisch-*.dump' -mtime "+$TAGE" -delete 2>/dev/null || true
}

# Einmal laufen und aufhören — praktisch zum Prüfen und für einen Aufruf von
# Hand vor einem Umbau.
if [ "${1:-}" = "einmal" ]; then
	sicherung
	exit $?
fi

while true; do
	sicherung || true
	sleep "$ABSTAND"
done
