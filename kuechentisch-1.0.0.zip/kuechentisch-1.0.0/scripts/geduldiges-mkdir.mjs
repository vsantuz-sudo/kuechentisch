/**
 * Geduldiges mkdir — eine Notbremse für den Build auf überlagernden Dateisystemen.
 *
 * Das Problem: rollup schreibt die Server-Bündel gleichzeitig und legt die
 * Zielverzeichnisse dabei mit `mkdir(…, { recursive: true })` an. Auf einem
 * gewöhnlichen Dateisystem ist das genau der richtige Weg — der Aufruf ist
 * dafür gedacht, mehrfach und nebenläufig gutzugehen. Auf den überlagernden
 * Dateisystemen, die Docker benutzt (overlay2, auf QNAP oft fuse-overlayfs),
 * kann er das nicht immer halten: legen zwei Aufrufe benachbarte Verzeichnisse
 * unter demselben neuen Elternverzeichnis an, bekommt einer davon ENOENT für
 * ein Elternverzeichnis, das der andere in genau diesem Augenblick anlegt.
 * Der Build bricht dann ab mit
 *   „ENOENT: no such file or directory, mkdir '/app/build/server/chunks/…'".
 *
 * Die Antwort darauf ist unspektakulär: noch einmal versuchen. Das Verzeichnis
 * ist einen Wimpernschlag später da, und `recursive: true` stört sich nicht
 * daran, dass es inzwischen existiert. Nur bei einem echten Fehler — kein
 * Platz, keine Rechte, falscher Pfad — geht der Fehler unverändert weiter
 * nach oben; wir verschleiern hier nichts.
 *
 * Eingehängt wird das über NODE_OPTIONS=--import im Dockerfile und in
 * scripts/installieren.sh. Ohne Wettrennen kostet es nichts: die Hülle reicht
 * den Aufruf einfach durch.
 *
 * Warum das überhaupt greift: rollup holt sich sein mkdir über
 * `import * as promises from 'node:fs/promises'`, und diese Namensraum-Bindung
 * zeigt auf dasselbe Objekt wie `fs.promises`. Wer dort die Eigenschaft
 * ersetzt, bevor rollup geladen wird — und --import läuft vor allem anderen —,
 * wird auch von rollup benutzt.
 */

import fs from 'node:fs';

const VERSUCHE = 8;
const PAUSE_MS = 20;

/** Fehler, die von einem Wettrennen kommen können und beim zweiten Mal weg sind. */
const FLUECHTIG = new Set(['ENOENT', 'EEXIST', 'EBUSY', 'EAGAIN']);

const schlafe = (ms) => new Promise((fertig) => setTimeout(fertig, ms));

const urspruenglich = fs.promises.mkdir;

async function geduldig(pfad, optionen) {
	let letzter;

	for (let versuch = 1; versuch <= VERSUCHE; versuch++) {
		try {
			return await urspruenglich.call(fs.promises, pfad, optionen);
		} catch (fehler) {
			// Nur das Wettrennen abfangen. Ein fehlendes Recht oder eine volle
			// Platte bleibt ein Fehler und soll den Build abbrechen — sonst
			// suchte man den wahren Grund später an der falschen Stelle.
			if (!optionen?.recursive || !FLUECHTIG.has(fehler?.code)) throw fehler;

			letzter = fehler;
			await schlafe(PAUSE_MS * versuch);
		}
	}

	throw letzter;
}

fs.promises.mkdir = geduldig;
