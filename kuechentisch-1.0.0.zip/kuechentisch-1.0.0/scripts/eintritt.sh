#!/bin/sh
# Was beim Start des Containers passiert, bevor die App läuft.
#
# Der Grund für diese Datei ist ein Fehler, der jede frische Installation
# getroffen hat: Der Foto-Upload endete mit
#
#   EACCES: permission denied, mkdir '/app/media/<haushalt>'
#
# Das Dockerfile legt `/app/media` an und übereignet es `node`. Nur hängt
# `docker-compose.yml` mit `./data/media:/app/media` einen Ordner vom
# Wirtssystem darüber, und ein Mount **überdeckt** den Ordner aus dem Abbild
# samt seiner Besitzverhältnisse. Existiert `data/media` auf dem Wirtssystem
# noch nicht, legt Docker ihn beim ersten Start selbst an — als root. Die App
# läuft aber als `node` und darf dort nichts anlegen.
#
# Deshalb: kurz als root die Besitzverhältnisse richten, dann die Rechte
# abgeben und die App als `node` starten. Dasselbe Vorgehen wie beim
# offiziellen Postgres-Abbild.
set -eu

# Derselbe Ort, den die App über MEDIA_DIR liest — so kann er nicht
# auseinanderlaufen. Und so lässt sich dieses Skript auch außerhalb von Docker
# prüfen, statt sich auf „sieht richtig aus" zu verlassen.
ZIEL=${MEDIA_DIR:-/app/media}
BENUTZER=${APP_BENUTZER:-node}

if [ "$(id -u)" = "0" ]; then
	mkdir -p "$ZIEL"

	# Nur wenn der Ordner jemand anderem gehört. Ein `chown -R` bei jedem Start
	# würde bei ein paar tausend Urlaubsfotos jedes Mal spürbar dauern, ohne
	# etwas zu ändern.
	if [ "$(stat -c %U "$ZIEL")" != "$BENUTZER" ]; then
		echo "Foto-Ordner gehört $(stat -c %U "$ZIEL") — wird auf $BENUTZER übertragen."
		chown -R "$BENUTZER:$BENUTZER" "$ZIEL"
	fi

	# Rechte abgeben. `setpriv` steckt in util-linux und ist in Debian
	# vorhanden; `su` ist der Rückfall, falls doch nicht.
	if command -v setpriv >/dev/null 2>&1; then
		exec setpriv --reuid="$BENUTZER" --regid="$BENUTZER" --init-groups "$@"
	fi

	if command -v su >/dev/null 2>&1; then
		echo "setpriv fehlt, weiche auf su aus."
		# Die einfachen Anführungszeichen sind Absicht: $0 und $@ sollen erst in
		# der inneren Shell eingesetzt werden, nicht hier. So bleibt der Befehl
		# samt seiner Argumente unversehrt, auch wenn Leerzeichen darin stehen.
		# shellcheck disable=SC2016
		exec su "$BENUTZER" -s /bin/sh -c 'exec "$0" "$@"' -- "$@"
	fi

	# Lieber laufend und laut als stumm gescheitert — aber niemals stillschweigend.
	echo "WARNUNG: Kann die Rechte nicht abgeben, die App läuft als root." >&2
	exec "$@"
fi

# Nicht root: nichts zu richten, nichts abzugeben.
exec "$@"
