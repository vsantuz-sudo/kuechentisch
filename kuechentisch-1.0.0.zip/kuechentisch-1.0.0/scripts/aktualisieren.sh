#!/usr/bin/env bash
#
# Küchentisch auf die neueste Fassung bringen.
#
#   bash scripts/aktualisieren.sh
#
# Holt das fertige Abbild aus der Registry und startet damit neu. Das ist
# alles — Datenbank-Migrationen laufen beim Start der App von selbst, und die
# Daten liegen in `data/` und bleiben, wo sie sind.
#
# Wer selbst baut (Entwicklung), braucht dieses Skript nicht: Dort holt
# `bash scripts/starten.sh` den neuen Stand aus dem Quellcode.
#
set -Eeuo pipefail

trap 'printf "\033[0;31m✗\033[0m Fehlgeschlagen: %s\n" "${BASH_COMMAND:-unbekannt}" >&2' ERR

ROT=$'\033[0;31m'; GRUEN=$'\033[0;32m'; GELB=$'\033[0;33m'; FETT=$'\033[1m'; AUS=$'\033[0m'

sage()    { printf '%s\n' "$*"; }
gut()     { printf '%s✓%s %s\n' "$GRUEN" "$AUS" "$*"; }
warn()    { printf '%s!%s %s\n' "$GELB" "$AUS" "$*"; }
abbruch() { printf '%s✗%s %s\n' "$ROT" "$AUS" "$*" >&2; exit 1; }

WURZEL="$(cd "$(dirname "$0")/.." && pwd)"
cd "$WURZEL"

COMPOSE="${KT_COMPOSE:-docker compose}"

[ -f .env ] || abbruch "Keine .env gefunden. Erst 'bash scripts/erststart.sh' ausführen."

aus_env() { grep -E "^$1=" .env 2>/dev/null | head -1 | cut -d= -f2- | tr -d '"'"'"'' || true ; }

MARKE="$(aus_env KT_MARKE)"
FASSUNG="$(aus_env KT_FASSUNG)"

sage ""
sage "${FETT}Küchentisch aktualisieren${AUS}"
sage ""

if [ -f docker-compose.override.yml ]; then
	warn "Hier liegt docker-compose.override.yml — diese Installation baut selbst."
	sage "  Für sie ist 'bash scripts/starten.sh' der richtige Befehl."
	sage ""
fi

if [ -z "$MARKE" ]; then
	abbruch "In der .env steht kein KT_MARKE. Ohne Registry gibt es nichts zu holen."
fi

sage "  Abbild:   $MARKE"
sage "  Fassung:  ${FASSUNG:-local}"
sage ""

# Erst holen, dann starten. Scheitert das Holen — Netz weg, Abo abgelaufen,
# Token gesperrt —, wird **nichts** angefasst: Die laufende Fassung bleibt
# unverändert in Betrieb. Das ist der Grund für die Trennung in zwei Schritte.
if ! $COMPOSE pull; then
	sage ""
	warn "Das Abbild konnte nicht geholt werden. Es wurde nichts verändert —"
	sage "  die bisherige Fassung läuft weiter."
	sage ""
	sage "  Mögliche Gründe:"
	sage "    • Keine Verbindung ins Internet."
	sage "    • Anmeldung fehlt oder abgelaufen:  docker login ${MARKE%%/*}"
	sage "    • Die Fassung $FASSUNG gibt es (noch) nicht."
	sage ""
	exit 1
fi

gut "Abbild geholt."
sage ""

bash scripts/starten.sh --ohne-bauen
